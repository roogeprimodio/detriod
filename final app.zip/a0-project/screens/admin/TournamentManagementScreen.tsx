import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  TextInput,
  StatusBar,
  ActivityIndicator,
  Modal,
  ScrollView,
  Alert
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialIcons, FontAwesome5, AntDesign } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { toast } from 'sonner-native';

// Import Firebase
import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs, doc, setDoc, updateDoc, deleteDoc, query, where, orderBy } from 'firebase/firestore';

// Sample tournament data (would come from Firebase in a real app)
const TOURNAMENTS = [
  {
    id: '1',
    title: 'Pro League Season 5',
    game: 'Call of Duty Mobile',
    image: 'https://api.a0.dev/assets/image?text=Call%20of%20Duty%20Tournament%20Poster&aspect=16:9&seed=123',
    prize: '$5,000',
    entryFee: 'Free',
    date: 'Jun 15-20',
    slots: '32/64',
    status: 'active',
    format: '5v5',
    organizer: 'ESL Gaming',
    registeredTeams: 32,
    totalMatches: 31,
    completedMatches: 12,
  },
  {
    id: '2',
    title: 'Ultimate Showdown',
    game: 'PUBG Mobile',
    image: 'https://api.a0.dev/assets/image?text=PUBG%20Mobile%20Tournament%20Banner&aspect=16:9&seed=456',
    prize: '$3,500',
    entryFee: '$10',
    date: 'Jun 22-25',
    slots: '45/100',
    status: 'active',
    format: 'Squad',
    organizer: 'Game Tourney',
    registeredTeams: 45,
    totalMatches: 45,
    completedMatches: 8,
  },
  {
    id: '3',
    title: 'Mythic Cup',
    game: 'Fortnite',
    image: 'https://api.a0.dev/assets/image?text=Fortnite%20Tournament%20Competition&aspect=16:9&seed=789',
    prize: '$7,000',
    entryFee: '$15',
    date: 'Jul 1-10',
    slots: '120/200',
    status: 'upcoming',
    format: 'Solo',
    organizer: 'Epic Events',
    registeredTeams: 120,
    totalMatches: 119,
    completedMatches: 0,
  },
  {
    id: '4',
    title: 'Regional Championship',
    game: 'Mobile Legends',
    image: 'https://api.a0.dev/assets/image?text=Mobile%20Legends%20Tournament%20Event&aspect=16:9&seed=101',
    prize: '$2,500',
    entryFee: 'Free',
    date: 'Jul 5-8',
    slots: '22/32',
    status: 'upcoming',
    format: '5v5',
    organizer: 'MGL Association',
    registeredTeams: 22,
    totalMatches: 31,
    completedMatches: 0,
  },
  {
    id: '5',
    title: 'Community Cup',
    game: 'Free Fire',
    image: 'https://api.a0.dev/assets/image?text=Free%20Fire%20Tournament%20Cup&aspect=16:9&seed=102',
    prize: '$1,200',
    entryFee: '$5',
    date: 'Jul 12-13',
    slots: '18/50',
    status: 'upcoming',
    format: 'Squad',
    organizer: 'Garena',
    registeredTeams: 18,
    totalMatches: 17,
    completedMatches: 0,
  },
  {
    id: '6',
    title: 'Summer Invitational',
    game: 'Valorant',
    image: 'https://api.a0.dev/assets/image?text=Valorant%20Summer%20Tournament&aspect=16:9&seed=103',
    prize: '$4,500',
    entryFee: '$12',
    date: 'Jun 1-5',
    slots: '16/16',
    status: 'completed',
    format: '5v5',
    organizer: 'Game Tourney',
    registeredTeams: 16,
    totalMatches: 15,
    completedMatches: 15,
  },
  {
    id: '7',
    title: 'Spring Championship',
    game: 'League of Legends: Wild Rift',
    image: 'https://api.a0.dev/assets/image?text=Wild%20Rift%20Tournament&aspect=16:9&seed=104',
    prize: '$3,000',
    entryFee: '$8',
    date: 'May 10-15',
    slots: '24/24',
    status: 'completed',
    format: '5v5',
    organizer: 'Riot Mobile Esports',
    registeredTeams: 24,
    totalMatches: 23,
    completedMatches: 23,
  },
];

const GAME_OPTIONS = [
  'Call of Duty Mobile',
  'PUBG Mobile',
  'Fortnite',
  'Free Fire',
  'Mobile Legends',
  'League of Legends: Wild Rift',
  'Valorant Mobile',
  'Clash Royale',
  'Brawl Stars',
  'Arena of Valor'
];

const FORMAT_OPTIONS = [
  'Solo',
  'Duo',
  'Squad',
  '5v5',
  '3v3',
  '1v1'
];

export default function TournamentManagementScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all'); // 'all', 'active', 'upcoming', 'completed'
  const [isLoading, setIsLoading] = useState(false);
  const [tournaments, setTournaments] = useState(TOURNAMENTS);
  
  // Form state
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [formTitle, setFormTitle] = useState('');
  const [formGame, setFormGame] = useState(GAME_OPTIONS[0]);
  const [formPrize, setFormPrize] = useState('');
  const [formEntryFee, setFormEntryFee] = useState('Free');
  const [formStartDate, setFormStartDate] = useState('');
  const [formEndDate, setFormEndDate] = useState('');
  const [formMaxSlots, setFormMaxSlots] = useState('');
  const [formFormat, setFormFormat] = useState(FORMAT_OPTIONS[0]);
  const [formDescription, setFormDescription] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState(null);
  
  // Check if we should show form directly (from dashboard "Create Tournament" action)
  useEffect(() => {
    if (route.params?.action === 'create') {
      setShowCreateModal(true);
    }
    
    if (route.params?.tournamentId) {
      // This would fetch the tournament data from Firebase by ID
      const tournament = TOURNAMENTS.find(t => t.id === route.params?.tournamentId);
      if (tournament) {
        handleEditTournament(tournament);
      }
    }
  }, [route.params]);
  
  // Load tournaments from Firebase (simulated)
  useEffect(() => {
    const loadTournaments = async () => {
      setIsLoading(true);
      // This would be a Firebase query in a real app
      setTimeout(() => {
        setTournaments(TOURNAMENTS);
        setIsLoading(false);
      }, 500);
    };
    
    loadTournaments();
  }, []);
  
  const filteredTournaments = tournaments.filter(tournament => {
    // Apply search filter
    const matchesSearch = tournament.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          tournament.game.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Apply status filter
    const matchesStatus = statusFilter === 'all' || tournament.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
  
  const resetForm = () => {
    setFormTitle('');
    setFormGame(GAME_OPTIONS[0]);
    setFormPrize('');
    setFormEntryFee('Free');
    setFormStartDate('');
    setFormEndDate('');
    setFormMaxSlots('');
    setFormFormat(FORMAT_OPTIONS[0]);
    setFormDescription('');
    setIsEditing(false);
    setEditingId(null);
  };
  
  const handleCreateTournament = () => {
    resetForm();
    setShowCreateModal(true);
  };
  
  const handleEditTournament = (tournament) => {
    setIsEditing(true);
    setEditingId(tournament.id);
    setFormTitle(tournament.title);
    setFormGame(tournament.game);
    setFormPrize(tournament.prize);
    setFormEntryFee(tournament.entryFee);
    
    // Parse date range like "Jun 15-20" into start and end dates
    const dateRange = tournament.date.split('-');
    setFormStartDate(dateRange[0].trim());
    setFormEndDate(dateRange.length > 1 ? dateRange[1].trim() : dateRange[0].trim());
    
    // Parse slots like "32/64" to get max slots
    const slots = tournament.slots.split('/');
    setFormMaxSlots(slots.length > 1 ? slots[1] : '100');
    
    setFormFormat(tournament.format);
    setFormDescription('Join the most competitive tournament of the season!');
    setShowCreateModal(true);
  };
  
  const handleDeleteTournament = (tournamentId) => {
    Alert.alert(
      'Delete Tournament',
      'Are you sure you want to delete this tournament? This action cannot be undone.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            // This would delete from Firebase in a real app
            const updatedTournaments = tournaments.filter(t => t.id !== tournamentId);
            setTournaments(updatedTournaments);
            toast.success('Tournament deleted successfully');
          },
        },
      ]
    );
  };
  
  const handleSubmitForm = () => {
    // Validate form
    if (!formTitle || !formPrize || !formStartDate || !formEndDate || !formMaxSlots) {
      toast.error('Please fill all required fields');
      return;
    }
    
    const tournamentData = {
      title: formTitle,
      game: formGame,
      prize: formPrize.startsWith('$') ? formPrize : `$${formPrize}`,
      entryFee: formEntryFee,
      date: `${formStartDate}-${formEndDate}`,
      slots: `0/${formMaxSlots}`,
      status: 'upcoming',
      format: formFormat,
      organizer: 'Game Tourney',
      image: `https://api.a0.dev/assets/image?text=${encodeURIComponent(formGame)}%20Tournament&aspect=16:9&seed=${Math.floor(Math.random() * 1000)}`,
      registeredTeams: 0,
      totalMatches: parseInt(formMaxSlots) - 1,
      completedMatches: 0,
    };
    
    if (isEditing) {
      // Update existing tournament (would use Firebase updateDoc in a real app)
      const updatedTournaments = tournaments.map(t => 
        t.id === editingId ? { ...t, ...tournamentData } : t
      );
      setTournaments(updatedTournaments);
      toast.success('Tournament updated successfully');
    } else {
      // Create new tournament (would use Firebase addDoc in a real app)
      const newTournament = {
        id: `${tournaments.length + 1}`,
        ...tournamentData
      };
      setTournaments([newTournament, ...tournaments]);
      toast.success('Tournament created successfully');
    }
    
    setShowCreateModal(false);
    resetForm();
  };
  
  const renderTournamentItem = ({ item }) => (
    <View style={styles.tournamentItem}>
      <View style={styles.tournamentHeader}>
        <View style={styles.tournamentTitleSection}>
          <View style={[
            styles.statusBadge, 
            { 
              backgroundColor: 
                item.status === 'active' ? '#E8F5E9' : 
                item.status === 'upcoming' ? '#E3F2FD' : '#FFF3E0'
            }
          ]}>
            <Text style={[
              styles.statusText,
              { 
                color: 
                  item.status === 'active' ? '#4CAF50' : 
                  item.status === 'upcoming' ? '#2196F3' : '#FF9800'
              }
            ]}>
              {item.status === 'active' ? 'Active' : 
               item.status === 'upcoming' ? 'Upcoming' : 'Completed'}
            </Text>
          </View>
          <Text style={styles.tournamentTitle}>{item.title}</Text>
          <Text style={styles.tournamentGame}>{item.game}</Text>
        </View>
        
        <View style={styles.tournamentActions}>
          <TouchableOpacity 
            style={[styles.actionButton, styles.editButton]}
            onPress={() => handleEditTournament(item)}
          >
            <MaterialIcons name="edit" size={18} color="#4361ee" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.actionButton, styles.deleteButton]}
            onPress={() => handleDeleteTournament(item.id)}
          >
            <MaterialIcons name="delete" size={18} color="#f44336" />
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.tournamentBody}>
        <View style={styles.detailColumn}>
          <View style={styles.detailRow}>
            <MaterialIcons name="attach-money" size={16} color="#4CAF50" />
            <Text style={styles.detailText}>Prize: {item.prize}</Text>
          </View>
          <View style={styles.detailRow}>
            <Ionicons name="time-outline" size={16} color="#FF9800" />
            <Text style={styles.detailText}>Date: {item.date}</Text>
          </View>
          <View style={styles.detailRow}>
            <MaterialIcons name="payment" size={16} color="#9C27B0" />
            <Text style={styles.detailText}>Entry: {item.entryFee}</Text>
          </View>
        </View>
        
        <View style={styles.detailColumn}>
          <View style={styles.detailRow}>
            <MaterialIcons name="people" size={16} color="#2196F3" />
            <Text style={styles.detailText}>Teams: {item.registeredTeams}</Text>
          </View>
          <View style={styles.detailRow}>
            <FontAwesome5 name="gamepad" size={14} color="#F44336" />
            <Text style={styles.detailText}>Format: {item.format}</Text>
          </View>
          <View style={styles.detailRow}>
            <MaterialIcons name="event" size={16} color="#607D8B" />
            <Text style={styles.detailText}>Matches: {item.completedMatches}/{item.totalMatches}</Text>
          </View>
        </View>
      </View>
      
      <View style={styles.tournamentFooter}>
        <TouchableOpacity 
          style={styles.viewButton}
          onPress={() => navigation.navigate('TournamentDetails' as never, { tournament: item } as never)}
        >
          <Text style={styles.viewButtonText}>View Details</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.manageButton, 
            item.status === 'completed' && styles.disabledButton
          ]}
          disabled={item.status === 'completed'}
          onPress={() => {/* Navigate to match management */}}
        >
          <Text style={[styles.manageButtonText,
            item.status === 'completed' && styles.disabledButtonText
          ]}>
            Manage Matches
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="chevron-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Tournament Management</Text>
        <TouchableOpacity 
          style={styles.createButton}
          onPress={handleCreateTournament}
        >
          <AntDesign name="plus" size={22} color="#4361ee" />
        </TouchableOpacity>
      </View>
      
      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#888" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search tournaments..."
          placeholderTextColor="#888"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        {searchQuery.length > 0 && (
          <TouchableOpacity 
            style={styles.clearButton}
            onPress={() => setSearchQuery('')}
          >
            <Ionicons name="close-circle" size={18} color="#888" />
          </TouchableOpacity>
        )}
      </View>
      
      <View style={styles.filterContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filtersScroll}
        >
          <TouchableOpacity 
            style={[styles.filterButton, statusFilter === 'all' && styles.activeFilterButton]}
            onPress={() => setStatusFilter('all')}
          >
            <Text style={[styles.filterText, statusFilter === 'all' && styles.activeFilterText]}>All</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.filterButton, statusFilter === 'active' && styles.activeFilterButton]}
            onPress={() => setStatusFilter('active')}
          >
            <View style={[styles.statusDot, { backgroundColor: '#4CAF50' }]} />
            <Text style={[styles.filterText, statusFilter === 'active' && styles.activeFilterText]}>Active</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.filterButton, statusFilter === 'upcoming' && styles.activeFilterButton]}
            onPress={() => setStatusFilter('upcoming')}
          >
            <View style={[styles.statusDot, { backgroundColor: '#2196F3' }]} />
            <Text style={[styles.filterText, statusFilter === 'upcoming' && styles.activeFilterText]}>Upcoming</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.filterButton, statusFilter === 'completed' && styles.activeFilterButton]}
            onPress={() => setStatusFilter('completed')}
          >
            <View style={[styles.statusDot, { backgroundColor: '#FF9800' }]} />
            <Text style={[styles.filterText, statusFilter === 'completed' && styles.activeFilterText]}>Completed</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
      
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4361ee" />
          <Text style={styles.loadingText}>Loading tournaments...</Text>
        </View>
      ) : (
        <FlatList
          data={filteredTournaments}
          renderItem={renderTournamentItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="alert-circle-outline" size={60} color="#ccc" />
              <Text style={styles.emptyTitle}>No tournaments found</Text>
              <Text style={styles.emptySubtitle}>Try adjusting your filters or create a new tournament</Text>
              <TouchableOpacity 
                style={styles.createEmptyButton}
                onPress={handleCreateTournament}
              >
                <AntDesign name="plus" size={16} color="#fff" />
                <Text style={styles.createEmptyText}>Create Tournament</Text>
              </TouchableOpacity>
            </View>
          }
        />
      )}
      
      {/* Create/Edit Tournament Modal */}
      <Modal
        visible={showCreateModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowCreateModal(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity 
              style={styles.modalCloseButton}
              onPress={() => {
                setShowCreateModal(false);
                resetForm();
              }}
            >
              <Ionicons name="close" size={24} color="#333" />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>{isEditing ? 'Edit Tournament' : 'Create Tournament'}</Text>
            <View style={styles.modalEmptySpace} />
          </View>
          
          <ScrollView style={styles.modalContent}>
            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Tournament Title<Text style={styles.required}>*</Text></Text>
              <TextInput
                style={styles.formInput}
                placeholder="Enter tournament title"
                placeholderTextColor="#888"
                value={formTitle}
                onChangeText={setFormTitle}
              />
            </View>
            
            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Game<Text style={styles.required}>*</Text></Text>
              <View style={styles.formInput}>
                <ScrollView 
                  horizontal 
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.gameOptionsContainer}
                >
                  {GAME_OPTIONS.map((game, index) => (
                    <TouchableOpacity
                      key={index}
                      style={[
                        styles.gameOption,
                        formGame === game && styles.selectedGameOption
                      ]}
                      onPress={() => setFormGame(game)}
                    >
                      <Text 
                        style={[
                          styles.gameOptionText,
                          formGame === game && styles.selectedGameOptionText
                        ]}
                      >
                        {game}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>
            </View>
            
            <View style={styles.formRow}>
              <View style={[styles.formGroup, { flex: 1, marginRight: 8 }]}>
                <Text style={styles.formLabel}>Prize Pool<Text style={styles.required}>*</Text></Text>
                <TextInput
                  style={styles.formInput}
                  placeholder="E.g., $5000"
                  placeholderTextColor="#888"
                  value={formPrize}
                  onChangeText={setFormPrize}
                  keyboardType="numeric"
                />
              </View>
              
              <View style={[styles.formGroup, { flex: 1, marginLeft: 8 }]}>
                <Text style={styles.formLabel}>Entry Fee<Text style={styles.required}>*</Text></Text>
                <View style={styles.entryFeeContainer}>
                  <TouchableOpacity 
                    style={[
                      styles.entryFeeOption,
                      formEntryFee === 'Free' && styles.selectedEntryFeeOption
                    ]}
                    onPress={() => setFormEntryFee('Free')}
                  >
                    <Text style={[
                      styles.entryFeeText,
                      formEntryFee === 'Free' && styles.selectedEntryFeeText
                    ]}>Free</Text>
                  </TouchableOpacity>
                  
                  <View style={styles.entryFeeInputContainer}>
                    <Text style={styles.dollarSign}>$</Text>
                    <TextInput
                      style={[
                        styles.entryFeeInput,
                        formEntryFee !== 'Free' && styles.activeEntryFeeInput
                      ]}
                      placeholder="10"
                      placeholderTextColor="#888"
                      value={formEntryFee !== 'Free' ? formEntryFee.replace('$', '') : ''}
                      onChangeText={(text) => setFormEntryFee(text ? `$${text}` : 'Free')}
                      keyboardType="numeric"
                      editable={formEntryFee !== 'Free'}
                    />
                  </View>
                </View>
              </View>
            </View>
            
            <View style={styles.formRow}>
              <View style={[styles.formGroup, { flex: 1, marginRight: 8 }]}>
                <Text style={styles.formLabel}>Start Date<Text style={styles.required}>*</Text></Text>
                <TextInput
                  style={styles.formInput}
                  placeholder="E.g., Jun 15"
                  placeholderTextColor="#888"
                  value={formStartDate}
                  onChangeText={setFormStartDate}
                />
              </View>
              
              <View style={[styles.formGroup, { flex: 1, marginLeft: 8 }]}>
                <Text style={styles.formLabel}>End Date<Text style={styles.required}>*</Text></Text>
                <TextInput
                  style={styles.formInput}
                  placeholder="E.g., Jun 20"
                  placeholderTextColor="#888"
                  value={formEndDate}
                  onChangeText={setFormEndDate}
                />
              </View>
            </View>
            
            <View style={styles.formRow}>
              <View style={[styles.formGroup, { flex: 1, marginRight: 8 }]}>
                <Text style={styles.formLabel}>Max Slots<Text style={styles.required}>*</Text></Text>
                <TextInput
                  style={styles.formInput}
                  placeholder="E.g., 64"
                  placeholderTextColor="#888"
                  value={formMaxSlots}
                  onChangeText={setFormMaxSlots}
                  keyboardType="numeric"
                />
              </View>
              
              <View style={[styles.formGroup, { flex: 1, marginLeft: 8 }]}>
                <Text style={styles.formLabel}>Format<Text style={styles.required}>*</Text></Text>
                <View style={styles.formatContainer}>
                  {FORMAT_OPTIONS.map((format, index) => (
                    <TouchableOpacity
                      key={index}
                      style={[
                        styles.formatOption,
                        formFormat === format && styles.selectedFormatOption
                      ]}
                      onPress={() => setFormFormat(format)}
                    >
                      <Text 
                        style={[
                          styles.formatOptionText,
                          formFormat === format && styles.selectedFormatOptionText
                        ]}
                      >
                        {format}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            </View>
            
            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Description</Text>
              <TextInput
                style={[styles.formInput, styles.textArea]}
                placeholder="Enter tournament description"
                placeholderTextColor="#888"
                value={formDescription}
                onChangeText={setFormDescription}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
              />
            </View>
          </ScrollView>
          
          <View style={styles.modalFooter}>
            <TouchableOpacity 
              style={styles.cancelButton}
              onPress={() => {
                setShowCreateModal(false);
                resetForm();
              }}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.submitButton}
              onPress={handleSubmitForm}
            >
              <Text style={styles.submitButtonText}>
                {isEditing ? 'Update Tournament' : 'Create Tournament'}
              </Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f9fc',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  createButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    height: 40,
    fontSize: 16,
    color: '#333',
  },
  clearButton: {
    padding: 4,
  },
  filterContainer: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    backgroundColor: '#fff',
  },
  filtersScroll: {
    paddingHorizontal: 12,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#eee',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    marginHorizontal: 4,
  },
  activeFilterButton: {
    backgroundColor: '#e3f2fd',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  filterText: {
    fontSize: 14,
    color: '#666',
  },
  activeFilterText: {
    color: '#2196F3',
    fontWeight: '500',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingBottom: 50,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#666',
  },
  listContainer: {
    padding: 16,
  },
  tournamentItem: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.08,
    shadowRadius: 2,
    elevation: 2,
    overflow: 'hidden',
  },
  tournamentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  tournamentTitleSection: {
    flex: 1,
  },
  statusBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginBottom: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
  },
  tournamentTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  tournamentGame: {
    fontSize: 14,
    color: '#666',
  },
  tournamentActions: {
    flexDirection: 'row',
  },  actionButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  editButton: {
    backgroundColor: '#e3f2fd',
  },
  deleteButton: {
    backgroundColor: '#ffebee',
  },
  tournamentBody: {
    flexDirection: 'row',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  detailColumn: {
    flex: 1,
  }