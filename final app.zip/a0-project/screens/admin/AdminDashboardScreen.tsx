import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  StatusBar,
  FlatList,
  Image
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialIcons, FontAwesome5, MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { LineChart } from 'react-native-chart-kit';
import { Dimensions } from 'react-native';

// Import Firebase
import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs, doc, setDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { getAuth, signOut } from 'firebase/auth';

// Firebase Configuration - Would come from environment variables in a real app
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-auth-domain.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-storage-bucket.appspot.com",
  messagingSenderId: "your-messaging-sender-id",
  appId: "your-app-id"
};

// Initialize Firebase
try {
  const app = initializeApp(firebaseConfig);
  const db = getFirestore(app);
  const auth = getAuth(app);
} catch (error) {
  console.log("Firebase already initialized or error:", error);
}

const TOURNAMENT_STATS = {
  active: 6,
  upcoming: 4,
  completed: 12,
  totalPlayers: 1230,
  totalTeams: 185,
  revenue: '$8,540',
};

const RECENT_TOURNAMENTS = [
  {
    id: '1',
    title: 'Pro League Season 5',
    game: 'Call of Duty Mobile',
    participants: 64,
    status: 'active',
    date: 'Jun 15-20',
  },
  {
    id: '2',
    title: 'Ultimate Showdown',
    game: 'PUBG Mobile',
    participants: 86,
    status: 'active',
    date: 'Jun 22-25',
  },
  {
    id: '3',
    title: 'Mythic Cup',
    game: 'Fortnite',
    participants: 128,
    status: 'upcoming',
    date: 'Jul 1-10',
  },
];

const RECENT_ACTIVITIES = [
  {
    id: '1',
    action: 'New team registration',
    tournament: 'Pro League Season 5',
    time: '2 hours ago',
    user: 'Voltage Esports',
  },
  {
    id: '2',
    action: 'Match result submitted',
    tournament: 'Pro League Season 5',
    time: '4 hours ago',
    user: 'Admin',
  },
  {
    id: '3',
    action: 'New user registered',
    tournament: '-',
    time: '6 hours ago',
    user: 'PredatorX',
  },
];

const screenWidth = Dimensions.get('window').width - 40;

const chartData = {
  labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
  datasets: [
    {
      data: [20, 35, 28, 45, 42, 50],
      color: (opacity = 1) => `rgba(67, 97, 238, ${opacity})`,
      strokeWidth: 2
    }
  ]
};

export default function AdminDashboardScreen() {
  const navigation = useNavigation();
  const [selectedPeriod, setSelectedPeriod] = useState('month'); // 'week', 'month', 'year'
  
  const handleSignOut = async () => {
    try {
      const auth = getAuth();
      await signOut(auth);
      // Navigation would happen based on auth state change listener in RootStack
    } catch (error) {
      console.error("Error signing out: ", error);
    }
  };

  const renderTournamentItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.tournamentCard}
      onPress={() => navigation.navigate('TournamentManagement' as never, { tournamentId: item.id } as never)}
    >
      <View style={styles.tournamentHeader}>
        <View style={[styles.statusIndicator, 
          { backgroundColor: item.status === 'active' ? '#4CAF50' : 
                            item.status === 'upcoming' ? '#2196F3' : '#FF9800' }
        ]} />
        <Text style={styles.tournamentGame}>{item.game}</Text>
      </View>
      <Text style={styles.tournamentTitle}>{item.title}</Text>
      <View style={styles.tournamentFooter}>
        <View style={styles.tournamentStat}>
          <Ionicons name="people-outline" size={16} color="#666" />
          <Text style={styles.tournamentStatText}>{item.participants} participants</Text>
        </View>
        <View style={styles.tournamentStat}>
          <Ionicons name="calendar-outline" size={16} color="#666" />
          <Text style={styles.tournamentStatText}>{item.date}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderActivityItem = ({ item }) => (
    <View style={styles.activityItem}>
      <View style={styles.activityIconContainer}>
        {item.action.includes('registration') ? (
          <MaterialCommunityIcons name="account-plus" size={16} color="#4361ee" />
        ) : item.action.includes('result') ? (
          <MaterialIcons name="emoji-events" size={16} color="#FF9800" />
        ) : (
          <MaterialIcons name="person-add" size={16} color="#4CAF50" />
        )}
      </View>
      <View style={styles.activityContent}>
        <Text style={styles.activityTitle}>{item.action}</Text>
        <Text style={styles.activitySubtitle}>
          {item.tournament !== '-' ? `${item.tournament} • ` : ''}{item.user}
        </Text>
      </View>
      <Text style={styles.activityTime}>{item.time}</Text>
    </View>
  );

  const renderPeriodButton = (period, label) => (
    <TouchableOpacity
      style={[styles.periodButton, selectedPeriod === period && styles.activePeriodButton]}
      onPress={() => setSelectedPeriod(period)}
    >
      <Text 
        style={[styles.periodButtonText, selectedPeriod === period && styles.activePeriodText]}
      >
        {label}
      </Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Admin Dashboard</Text>
          <Text style={styles.headerSubtitle}>Manage your tournaments</Text>
        </View>
        <TouchableOpacity 
          style={styles.profileButton}
          onPress={() => navigation.navigate('Profile' as never)}
        >
          <Image 
            source={{ uri: 'https://api.a0.dev/assets/image?text=Admin%20Profile&aspect=1:1&seed=789' }} 
            style={styles.profileImage} 
          />
        </TouchableOpacity>
      </View>
      
      <ScrollView 
        style={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.statsContainer}>
          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <View style={[styles.statIconContainer, { backgroundColor: '#E3F2FD' }]}>
                <MaterialIcons name="event-available" size={22} color="#2196F3" />
              </View>
              <View style={styles.statInfo}>
                <Text style={styles.statValue}>{TOURNAMENT_STATS.active}</Text>
                <Text style={styles.statLabel}>Active</Text>
              </View>
            </View>
            
            <View style={styles.statCard}>
              <View style={[styles.statIconContainer, { backgroundColor: '#E8F5E9' }]}>
                <MaterialIcons name="event" size={22} color="#4CAF50" />
              </View>
              <View style={styles.statInfo}>
                <Text style={styles.statValue}>{TOURNAMENT_STATS.upcoming}</Text>
                <Text style={styles.statLabel}>Upcoming</Text>
              </View>
            </View>
            
            <View style={styles.statCard}>
              <View style={[styles.statIconContainer, { backgroundColor: '#FFF3E0' }]}>
                <MaterialIcons name="event-busy" size={22} color="#FF9800" />
              </View>
              <View style={styles.statInfo}>
                <Text style={styles.statValue}>{TOURNAMENT_STATS.completed}</Text>
                <Text style={styles.statLabel}>Completed</Text>
              </View>
            </View>
          </View>
          
          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <View style={[styles.statIconContainer, { backgroundColor: '#E8EAF6' }]}>
                <Ionicons name="people" size={22} color="#3F51B5" />
              </View>
              <View style={styles.statInfo}>
                <Text style={styles.statValue}>{TOURNAMENT_STATS.totalPlayers}</Text>
                <Text style={styles.statLabel}>Players</Text>
              </View>
            </View>
            
            <View style={styles.statCard}>
              <View style={[styles.statIconContainer, { backgroundColor: '#F3E5F5' }]}>
                <MaterialIcons name="group-work" size={22} color="#9C27B0" />
              </View>
              <View style={styles.statInfo}>
                <Text style={styles.statValue}>{TOURNAMENT_STATS.totalTeams}</Text>
                <Text style={styles.statLabel}>Teams</Text>
              </View>
            </View>
            
            <View style={styles.statCard}>
              <View style={[styles.statIconContainer, { backgroundColor: '#E0F2F1' }]}>
                <MaterialIcons name="attach-money" size={22} color="#009688" />
              </View>
              <View style={styles.statInfo}>
                <Text style={styles.statValue}>{TOURNAMENT_STATS.revenue}</Text>
                <Text style={styles.statLabel}>Revenue</Text>
              </View>
            </View>
          </View>
        </View>
        
        <View style={styles.chartContainer}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Tournament Growth</Text>
            <View style={styles.periodButtons}>
              {renderPeriodButton('week', 'Week')}
              {renderPeriodButton('month', 'Month')}
              {renderPeriodButton('year', 'Year')}
            </View>
          </View>
          
          <LineChart
            data={chartData}
            width={screenWidth}
            height={180}
            chartConfig={{
              backgroundColor: '#fff',
              backgroundGradientFrom: '#fff',
              backgroundGradientTo: '#fff',
              decimalPlaces: 0,
              color: (opacity = 1) => `rgba(67, 97, 238, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            bezier
            style={styles.chart}
          />
        </View>
        
        <View style={styles.quickActions}>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => navigation.navigate('TournamentManagement' as never, { action: 'create' } as never)}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#4361ee' }]}>
              <MaterialIcons name="add" size={24} color="#fff" />
            </View>
            <Text style={styles.actionText}>Create Tournament</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => navigation.navigate('UserManagement' as never)}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#4CAF50' }]}>
              <MaterialIcons name="people" size={24} color="#fff" />
            </View>
            <Text style={styles.actionText}>Manage Users</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => navigation.navigate('Advertisement' as never)}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#FF9800' }]}>
              <MaterialIcons name="campaign" size={24} color="#fff" />
            </View>
            <Text style={styles.actionText}>Promotions</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => {/* Analytics functionality */}}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#9C27B0' }]}>
              <MaterialIcons name="insert-chart" size={24} color="#fff" />
            </View>
            <Text style={styles.actionText}>Analytics</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Tournaments</Text>
            <TouchableOpacity 
              style={styles.viewAllButton}
              onPress={() => navigation.navigate('TournamentManagement' as never)}
            >
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          
          <FlatList
            data={RECENT_TOURNAMENTS}
            renderItem={renderTournamentItem}
            keyExtractor={item => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.tournamentsList}
          />
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Activities</Text>
            <TouchableOpacity style={styles.viewAllButton}>
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.activitiesContainer}>
            <FlatList
              data={RECENT_ACTIVITIES}
              renderItem={renderActivityItem}
              keyExtractor={item => item.id}
              scrollEnabled={false}
              ItemSeparatorComponent={() => <View style={styles.activitySeparator} />}
            />
          </View>
        </View>
        
        <View style={styles.buttonContainer}>
          <TouchableOpacity 
            style={styles.signoutButton}
            onPress={handleSignOut}
          >
            <Ionicons name="log-out-outline" size={20} color="#f44336" />
            <Text style={styles.signoutButtonText}>Sign Out</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f9fc',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  profileButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
  },
  profileImage: {
    width: '100%',
    height: '100%',
  },
  content: {
    flex: 1,
  },
  statsContainer: {
    padding: 20,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    width: '30%',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 1.41,
    elevation: 2,
  },
  statIconContainer: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  statInfo: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  chartContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginHorizontal: 20,
    padding: 16,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 1.41,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  periodButtons: {
    flexDirection: 'row',
    backgroundColor: '#f4f4f4',
    borderRadius: 16,
    padding: 3,
  },
  periodButton: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 14,
  },
  activePeriodButton: {
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 1.0,
    elevation: 1,
  },
  periodButtonText: {
    fontSize: 12,
    color: '#666',
  },
  activePeriodText: {
    color: '#333',
    fontWeight: '600',
  },
  chart: {
    marginVertical: 8,
    borderRadius: 16,
  },
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  actionButton: {
    width: '48%',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 1.41,
    elevation: 2,
  },
  actionIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  actionText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  section: {
    marginHorizontal: 20,
    marginBottom: 20,
  },
  viewAllButton: {
    
  },
  viewAllText: {
    fontSize: 14,
    color: '#4361ee',
  },
  tournamentsList: {
    paddingRight: 20,
  },
  tournamentCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    width: 200,
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 1.41,
    elevation: 2,
  },
  tournamentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  statusIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  tournamentGame: {
    fontSize: 12,
    color: '#666',
  },
  tournamentTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  tournamentFooter: {
    
  },
  tournamentStat: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  tournamentStatText: {
    fontSize: 12,
    color: '#666',
    marginLeft: 6,
  },
  activitiesContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 1.41,
    elevation: 2,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  activityIconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  activityContent: {
    flex: 1,
  },
  activityTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
    marginBottom: 2,
  },
  activitySubtitle: {
    fontSize: 12,
    color: '#666',
  },
  activityTime: {
    fontSize: 11,
    color: '#999',
  },
  activitySeparator: {
    height: 1,
    backgroundColor: '#eee',
  },
  buttonContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  signoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    backgroundColor: '#ffebee',
    borderRadius: 24,
  },
  signoutButtonText: {
    color: '#f44336',
    fontWeight: '500',
    marginLeft: 8,
  },
});