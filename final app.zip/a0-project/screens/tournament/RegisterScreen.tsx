import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  ScrollView, 
  TextInput,
  Switch,
  KeyboardAvoidingView,
  Platform,
  Alert
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialIcons, FontAwesome5 } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { toast } from 'sonner-native';

const TEAM_MEMBERS = [
  { id: '1', name: 'Your Name', role: 'Captain', confirmed: true },
  { id: '2', name: '', role: 'Player 2', confirmed: false },
  { id: '3', name: '', role: 'Player 3', confirmed: false },
  { id: '4', name: '', role: 'Player 4', confirmed: false },
  { id: '5', name: '', role: 'Player 5', confirmed: false },
];

export default function RegisterScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const tournament = route.params?.tournament || {};
  
  const [teamName, setTeamName] = useState('');
  const [teamMembers, setTeamMembers] = useState(TEAM_MEMBERS);
  const [teamTag, setTeamTag] = useState('');
  const [agreedToRules, setAgreedToRules] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [registrationType, setRegistrationType] = useState('team'); // 'team' or 'solo'
  
  // Solo registration fields
  const [gameName, setGameName] = useState('');
  const [gameId, setGameId] = useState('');
  
  const updateTeamMember = (id, name) => {
    const updatedMembers = teamMembers.map(member => 
      member.id === id ? { ...member, name } : member
    );
    setTeamMembers(updatedMembers);
  };
  
  const handleInvite = (id) => {
    toast.success('Invitation sent successfully');
    const updatedMembers = teamMembers.map(member => 
      member.id === id ? { ...member, invited: true } : member
    );
    setTeamMembers(updatedMembers);
  };
  
  const handleRegistration = () => {
    // Validate form based on registration type
    if (registrationType === 'team') {
      if (!teamName) {
        toast.error('Please enter your team name');
        return;
      }
      
      // Check if at least the required number of players are added
      const filledMembers = teamMembers.filter(member => member.name.trim() !== '');
      if (filledMembers.length < 2) { // Assuming we need at least 2 players for demo
        toast.error('Please add at least one teammate');
        return;
      }
    } else {
      if (!gameName || !gameId) {
        toast.error('Please fill all required fields');
        return;
      }
    }
    
    if (!agreedToRules) {
      toast.error('Please agree to tournament rules');
      return;
    }
    
    setIsLoading(true);
    
    // Simulate registration process
    setTimeout(() => {
      setIsLoading(false);
      // Navigate to success screen or home screen
      navigation.navigate('MatchDetails' as never, { 
        tournament,
        registered: true 
      } as never);
      toast.success('Registration successful!');
    }, 1500);
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardAvoidContainer}
      >
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Ionicons name="chevron-back" size={24} color="#333" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Tournament Registration</Text>
          <View style={styles.emptySpace} />
        </View>
        
        <ScrollView 
          style={styles.content}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.tournamentInfo}>
            <Text style={styles.tournamentTitle}>{tournament.title}</Text>
            <Text style={styles.tournamentGame}>{tournament.game}</Text>
            <View style={styles.tournamentDetails}>
              <View style={styles.detailItem}>
                <MaterialIcons name="event" size={16} color="#5C6BC0" />
                <Text style={styles.detailText}>{tournament.date}</Text>
              </View>
              <View style={styles.detailItem}>
                <FontAwesome5 name="gamepad" size={14} color="#9C27B0" />
                <Text style={styles.detailText}>Format: {tournament.format}</Text>
              </View>
            </View>
          </View>
          
          <View style={styles.registrationTypeContainer}>
            <Text style={styles.sectionTitle}>Registration Type</Text>
            <View style={styles.registrationTypeButtons}>
              <TouchableOpacity 
                style={[
                  styles.typeButton,
                  registrationType === 'team' && styles.activeTypeButton
                ]}
                onPress={() => setRegistrationType('team')}
              >
                <MaterialIcons 
                  name="groups" 
                  size={22} 
                  color={registrationType === 'team' ? '#fff' : '#666'} 
                />
                <Text 
                  style={[
                    styles.typeText,
                    registrationType === 'team' && styles.activeTypeText
                  ]}
                >
                  Team
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[
                  styles.typeButton,
                  registrationType === 'solo' && styles.activeTypeButton
                ]}
                onPress={() => setRegistrationType('solo')}
              >
                <MaterialIcons 
                  name="person" 
                  size={22} 
                  color={registrationType === 'solo' ? '#fff' : '#666'} 
                />
                <Text 
                  style={[
                    styles.typeText,
                    registrationType === 'solo' && styles.activeTypeText
                  ]}
                >
                  Solo
                </Text>
              </TouchableOpacity>
            </View>
          </View>
          
          {registrationType === 'team' ? (
            <View style={styles.teamInfoContainer}>
              <Text style={styles.sectionTitle}>Team Information</Text>
              
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Team Name<Text style={styles.required}>*</Text></Text>
                <View style={styles.inputWrapper}>
                  <TextInput
                    style={styles.input}
                    placeholder="Enter your team name"
                    placeholderTextColor="#888"
                    value={teamName}
                    onChangeText={setTeamName}
                  />
                </View>
              </View>
              
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Team Tag (Optional)</Text>
                <View style={styles.inputWrapper}>
                  <TextInput
                    style={styles.input}
                    placeholder="E.g., [TAG]"
                    placeholderTextColor="#888"
                    value={teamTag}
                    onChangeText={setTeamTag}
                    maxLength={5}
                  />
                </View>
              </View>
              
              <Text style={styles.sectionTitle}>Team Members</Text>
              <Text style={styles.sectionSubtitle}>Add your team members</Text>
              
              {teamMembers.map((member, index) => (
                <View key={member.id} style={styles.memberContainer}>
                  <View style={styles.memberInfo}>
                    <Text style={styles.memberRole}>{member.role}</Text>
                    {member.confirmed && (
                      <View style={styles.confirmedBadge}>
                        <MaterialIcons name="check" size={12} color="#4CAF50" />
                        <Text style={styles.confirmedText}>Confirmed</Text>
                      </View>
                    )}
                  </View>
                  <View style={styles.memberInputRow}>
                    <View style={[styles.inputWrapper, styles.memberInput]}>
                      <TextInput
                        style={styles.input}
                        placeholder={`Enter ${member.role} name`}
                        placeholderTextColor="#888"
                        value={member.name}
                        onChangeText={(text) => updateTeamMember(member.id, text)}
                        editable={index === 0 ? false : true}
                      />
                    </View>
                    {index > 0 && (
                      <TouchableOpacity 
                        style={[
                          styles.inviteButton,
                          member.invited && styles.invitedButton
                        ]}
                        onPress={() => handleInvite(member.id)}
                        disabled={member.invited}
                      >
                        <Text style={styles.inviteButtonText}>
                          {member.invited ? 'Invited' : 'Invite'}
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <View style={styles.soloInfoContainer}>
              <Text style={styles.sectionTitle}>Player Information</Text>
              
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>In-Game Name<Text style={styles.required}>*</Text></Text>
                <View style={styles.inputWrapper}>
                  <TextInput
                    style={styles.input}
                    placeholder="Enter your in-game name"
                    placeholderTextColor="#888"
                    value={gameName}
                    onChangeText={setGameName}
                  />
                </View>
              </View>
              
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Game ID<Text style={styles.required}>*</Text></Text>
                <View style={styles.inputWrapper}>
                  <TextInput
                    style={styles.input}
                    placeholder="Enter your game ID"
                    placeholderTextColor="#888"
                    value={gameId}
                    onChangeText={setGameId}
                  />
                </View>
              </View>
            </View>
          )}
          
          <View style={styles.rulesContainer}>
            <View style={styles.rulesHeader}>
              <Text style={styles.rulesTitle}>Tournament Rules</Text>
              <TouchableOpacity style={styles.viewRulesButton}>
                <Text style={styles.viewRulesText}>View Full Rules</Text>
              </TouchableOpacity>
            </View>
            
            <View style={styles.ruleSummary}>
              <Text style={styles.ruleSummaryItem}>• Players must be at least 16 years old</Text>
              <Text style={styles.ruleSummaryItem}>• Team must consist of 5 players (for team mode)</Text>
              <Text style={styles.ruleSummaryItem}>• Check-in required 30 mins before match</Text>
              <Text style={styles.ruleSummaryItem}>• No toxic behavior or cheating allowed</Text>
            </View>
            
            <View style={styles.agreementContainer}>
              <Switch
                value={agreedToRules}
                onValueChange={setAgreedToRules}
                trackColor={{ false: '#ccc', true: '#a7c4ff' }}
                thumbColor={agreedToRules ? '#4361ee' : '#f4f3f4'}
              />
              <Text style={styles.agreementText}>
                I have read and agree to the tournament rules
              </Text>
            </View>
          </View>
          
          <View style={styles.paymentContainer}>
            <Text style={styles.paymentTitle}>Registration Fee</Text>
            <Text style={styles.paymentAmount}>
              {tournament.entryFee === 'Free' ? 'Free Entry' : tournament.entryFee}
            </Text>
          </View>
          
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={[
                styles.registerButton,
                (!agreedToRules || isLoading) && styles.disabledButton
              ]}
              onPress={handleRegistration}
              disabled={!agreedToRules || isLoading}
            >
              <Text style={styles.registerButtonText}>
                {isLoading ? 'Registering...' : 'Complete Registration'}
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f9fc',
  },
  keyboardAvoidContainer: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    backgroundColor: '#fff',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  emptySpace: {
    width: 40,
  },
  content: {
    flex: 1,
  },
  tournamentInfo: {
    backgroundColor: '#fff',
    padding: 16,
    marginBottom: 12,
  },
  tournamentTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  tournamentGame: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
  },
  tournamentDetails: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  detailText: {
    fontSize: 13,
    color: '#666',
    marginLeft: 6,
  },
  registrationTypeContainer: {
    backgroundColor: '#fff',
    padding: 16,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  registrationTypeButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  typeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '48%',
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: '#f4f4f4',
  },
  activeTypeButton: {
    backgroundColor: '#4361ee',
  },
  typeText: {
    fontSize: 15,
    fontWeight: '500',
    color: '#666',
    marginLeft: 8,
  },
  activeTypeText: {
    color: '#fff',
  },
  teamInfoContainer: {
    backgroundColor: '#fff',
    padding: 16,
    marginBottom: 12,
  },
  inputContainer: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
    marginBottom: 8,
  },
  required: {
    color: '#f44336',
  },
  inputWrapper: {
    backgroundColor: '#f7f9fc',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    paddingHorizontal: 12,
  },
  input: {
    height: 44,
    fontSize: 15,
    color: '#333',
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 16,
  },
  memberContainer: {
    marginBottom: 16,
  },
  memberInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  memberRole: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  confirmedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#e8f5e9',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 12,
    marginLeft: 8,
  },
  confirmedText: {
    fontSize: 11,
    color: '#4CAF50',
    marginLeft: 3,
  },
  memberInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  memberInput: {
    flex: 1,
  },
  inviteButton: {
    backgroundColor: '#e3f2fd',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 6,
    marginLeft: 8,
  },
  invitedButton: {
    backgroundColor: '#e8f5e9',
  },
  inviteButtonText: {
    fontSize: 13,
    fontWeight: '500',
    color: '#2196F3',
  },
  soloInfoContainer: {
    backgroundColor: '#fff',
    padding: 16,
    marginBottom: 12,
  },
  rulesContainer: {
    backgroundColor: '#fff',
    padding: 16,
    marginBottom: 12,
  },
  rulesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  rulesTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  viewRulesButton: {
    
  },
  viewRulesText: {
    fontSize: 13,
    color: '#4361ee',
    fontWeight: '500',
  },
  ruleSummary: {
    backgroundColor: '#f7f9fc',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  ruleSummaryItem: {
    fontSize: 13,
    color: '#666',
    marginBottom: 8,
    lineHeight: 20,
  },
  agreementContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  agreementText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
    flex: 1,
  },
  paymentContainer: {
    backgroundColor: '#fff',
    padding: 16,
    marginBottom: 24,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  paymentTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  paymentAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: tournament => tournament.entryFee === 'Free' ? '#4CAF50' : '#4361ee',
  },
  buttonContainer: {
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  registerButton: {
    backgroundColor: '#4361ee',
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
  },
  disabledButton: {
    backgroundColor: '#a0a0a0',
  },
  registerButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});