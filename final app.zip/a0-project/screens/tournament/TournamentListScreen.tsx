import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  Image, 
  TextInput, 
  StatusBar
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialIcons, FontAwesome5 } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';

const TOURNAMENTS = [
  {
    id: '1',
    title: 'Pro League Season 5',
    game: 'Call of Duty Mobile',
    image: 'https://api.a0.dev/assets/image?text=Call%20of%20Duty%20Tournament%20Poster&aspect=16:9&seed=123',
    prize: '$5,000',
    entryFee: 'Free',
    date: 'Jun 15-20',
    slots: '32/64',
    status: 'open',
    format: '5v5',
    organizer: 'ESL Gaming',
    verifiedOrganizer: true,
  },
  {
    id: '2',
    title: 'Ultimate Showdown',
    game: 'PUBG Mobile',
    image: 'https://api.a0.dev/assets/image?text=PUBG%20Mobile%20Tournament%20Banner&aspect=16:9&seed=456',
    prize: '$3,500',
    entryFee: '$10',
    date: 'Jun 22-25',
    slots: '45/100',
    status: 'open',
    format: 'Squad',
    organizer: 'Game Tourney',
    verifiedOrganizer: true,
  },
  {
    id: '3',
    title: 'Mythic Cup',
    game: 'Fortnite',
    image: 'https://api.a0.dev/assets/image?text=Fortnite%20Tournament%20Competition&aspect=16:9&seed=789',
    prize: '$7,000',
    entryFee: '$15',
    date: 'Jul 1-10',
    slots: '120/200',
    status: 'open',
    format: 'Solo',
    organizer: 'Epic Events',
    verifiedOrganizer: false,
  },
  {
    id: '4',
    title: 'Regional Championship',
    game: 'Mobile Legends',
    image: 'https://api.a0.dev/assets/image?text=Mobile%20Legends%20Tournament%20Event&aspect=16:9&seed=101',
    prize: '$2,500',
    entryFee: 'Free',
    date: 'Jul 5-8',
    slots: '22/32',
    status: 'open',
    format: '5v5',
    organizer: 'MGL Association',
    verifiedOrganizer: true,
  },
  {
    id: '5',
    title: 'Community Cup',
    game: 'Free Fire',
    image: 'https://api.a0.dev/assets/image?text=Free%20Fire%20Tournament%20Cup&aspect=16:9&seed=102',
    prize: '$1,200',
    entryFee: '$5',
    date: 'Jul 12-13',
    slots: '18/50',
    status: 'open',
    format: 'Squad',
    organizer: 'Garena',
    verifiedOrganizer: true,
  },
];

const FILTERS = [
  'All',
  'Free Entry',
  'Paid Entry',
  'Singles',
  'Teams',
  'This Week',
  'This Month'
];

export default function TournamentListScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState(FILTERS[0]);
  
  // Get the game data from route params
  const game = route.params?.game || { name: 'All Games' };
  
  const filteredTournaments = TOURNAMENTS.filter(tournament => {
    // Search query filter
    const matchesSearch = tournament.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tournament.game.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Game filter (if specific game is selected)
    const matchesGame = !game.id || tournament.game === game.name;
    
    // Additional filters
    let matchesFilter = true;
    if (selectedFilter === 'Free Entry') {
      matchesFilter = tournament.entryFee === 'Free';
    } else if (selectedFilter === 'Paid Entry') {
      matchesFilter = tournament.entryFee !== 'Free';
    } else if (selectedFilter === 'Singles') {
      matchesFilter = tournament.format === 'Solo';
    } else if (selectedFilter === 'Teams') {
      matchesFilter = tournament.format !== 'Solo';
    }
    // You would add more date logic for This Week/Month filters
    
    return matchesSearch && matchesGame && matchesFilter;
  });

  const handleTournamentPress = (tournament) => {
    navigation.navigate('TournamentDetails' as never, { tournament } as never);
  };

  const renderTournamentItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.tournamentCard}
      onPress={() => handleTournamentPress(item)}
    >
      <Image source={{ uri: item.image }} style={styles.tournamentImage} />
      <View style={styles.tournamentBody}>
        <View style={styles.tournamentHeader}>
          <Text style={styles.tournamentGame}>{item.game}</Text>
          <View style={styles.statusContainer}>
            <View style={styles.statusDot} />
            <Text style={styles.statusText}>Registrations Open</Text>
          </View>
        </View>
        
        <Text style={styles.tournamentTitle}>{item.title}</Text>
        
        <View style={styles.tournamentInfo}>
          <View style={styles.infoItem}>
            <MaterialIcons name="attach-money" size={16} color="#4CAF50" />
            <Text style={styles.infoText}>Prize: {item.prize}</Text>
          </View>
          
          <View style={styles.infoItem}>
            <MaterialIcons name="event" size={16} color="#5C6BC0" />
            <Text style={styles.infoText}>{item.date}</Text>
          </View>
        </View>
        
        <View style={styles.tournamentInfo}>
          <View style={styles.infoItem}>
            <MaterialIcons name="people" size={16} color="#FF9800" />
            <Text style={styles.infoText}>Slots: {item.slots}</Text>
          </View>
          
          <View style={styles.infoItem}>
            <FontAwesome5 name="gamepad" size={14} color="#9C27B0" />
            <Text style={styles.infoText}>Format: {item.format}</Text>
          </View>
        </View>
        
        <View style={styles.tournamentFooter}>
          <View style={styles.organizerContainer}>
            <Text style={styles.organizerText}>By {item.organizer}</Text>
            {item.verifiedOrganizer && (
              <MaterialIcons name="verified" size={14} color="#4361ee" style={styles.verifiedIcon} />
            )}
          </View>
          
          <View style={styles.entryContainer}>
            <Text style={styles.entryText}>
              {item.entryFee === 'Free' ? 'Free Entry' : `Entry: ${item.entryFee}`}
            </Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderFilterItem = ({ item }) => (
    <TouchableOpacity
      style={[
        styles.filterButton,
        selectedFilter === item && styles.activeFilterButton
      ]}
      onPress={() => setSelectedFilter(item)}
    >
      <Text 
        style={[
          styles.filterText,
          selectedFilter === item && styles.activeFilterText
        ]}
      >
        {item}
      </Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="chevron-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {game.id ? `${game.name} Tournaments` : 'All Tournaments'}
        </Text>
        <TouchableOpacity style={styles.filterIconButton}>
          <Ionicons name="filter" size={22} color="#333" />
        </TouchableOpacity>
      </View>
      
      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#888" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search tournaments..."
          placeholderTextColor="#888"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        {searchQuery.length > 0 && (
          <TouchableOpacity 
            style={styles.clearButton}
            onPress={() => setSearchQuery('')}
          >
            <Ionicons name="close-circle" size={18} color="#888" />
          </TouchableOpacity>
        )}
      </View>
      
      <View style={styles.filtersList}>
        <FlatList
          data={FILTERS}
          renderItem={renderFilterItem}
          keyExtractor={(item) => item}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filtersContainer}
        />
      </View>
      
      <View style={styles.content}>
        <FlatList
          data={filteredTournaments}
          renderItem={renderTournamentItem}
          keyExtractor={item => item.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.tournamentsList}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="search-outline" size={60} color="#ccc" />
              <Text style={styles.emptyTitle}>No tournaments found</Text>
              <Text style={styles.emptySubtitle}>Try changing your search or filters</Text>
            </View>
          }
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f9fc',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  filterIconButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    marginHorizontal: 16,
    marginTop: 16,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#eee',
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    height: 40,
    fontSize: 16,
    color: '#333',
  },
  clearButton: {
    padding: 4,
  },
  filtersList: {
    marginTop: 16,
  },
  filtersContainer: {
    paddingHorizontal: 12,
  },
  filterButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#eee',
    marginHorizontal: 4,
  },
  activeFilterButton: {
    backgroundColor: '#4361ee',
  },
  filterText: {
    color: '#666',
    fontWeight: '500',
  },
  activeFilterText: {
    color: '#fff',
  },
  content: {
    flex: 1,
    marginTop: 12,
  },
  tournamentsList: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  tournamentCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 3,
  },
  tournamentImage: {
    width: '100%',
    height: 130,
  },
  tournamentBody: {
    padding: 12,
  },
  tournamentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  tournamentGame: {
    fontSize: 13,
    color: '#666',
    fontWeight: '500',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#4CAF50',
    marginRight: 4,
  },
  statusText: {
    fontSize: 12,
    color: '#4CAF50',
  },
  tournamentTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  tournamentInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  infoText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 4,
  },
  tournamentFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  organizerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  organizerText: {
    fontSize: 12,
    color: '#888',
  },
  verifiedIcon: {
    marginLeft: 4,
  },
  entryContainer: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    backgroundColor: item => item.entryFee === 'Free' ? '#E8F5E9' : '#E3F2FD',
    borderRadius: 12,
  },
  entryText: {
    fontSize: 12,
    fontWeight: '500',
    color: item => item.entryFee === 'Free' ? '#4CAF50' : '#2196F3',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#888',
    marginTop: 8,
  },
});