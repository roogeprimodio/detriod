import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  ScrollView, 
  TouchableOpacity, 
  StatusBar,
  FlatList,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialIcons, FontAwesome5, MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';

// Sample schedule data
const SCHEDULE = [
  {
    id: '1',
    round: 'Qualifiers',
    date: 'June 15-16, 2023',
    time: '2:00 PM - 9:00 PM',
    status: 'upcoming'
  },
  {
    id: '2',
    round: 'Quarter Finals',
    date: 'June 17, 2023',
    time: '4:00 PM - 8:00 PM',
    status: 'upcoming'
  },
  {
    id: '3',
    round: 'Semi Finals',
    date: 'June 18, 2023',
    time: '5:00 PM - 8:00 PM',
    status: 'upcoming'
  },
  {
    id: '4',
    round: 'Finals',
    date: 'June 20, 2023',
    time: '7:00 PM - 10:00 PM',
    status: 'upcoming'
  }
];

// Sample rules
const RULES = [
  "Players must be at least 16 years of age to participate",
  "Team must consist of 5 players with up to 2 substitutes",
  "All matches will be played on the official tournament server",
  "Teams must check-in 30 minutes before their scheduled match time",
  "Match results must be submitted through the tournament app immediately after completion",
  "Misconduct will result in disqualification at admins' discretion",
  "Tournament admins' decisions are final"
];

// Sample prizes
const PRIZES = [
  {
    rank: '1st Place',
    prize: '$3,000',
  },
  {
    rank: '2nd Place',
    prize: '$1,200',
  },
  {
    rank: '3rd Place',
    prize: '$500',
  },
  {
    rank: '4th Place',
    prize: '$300',
  }
];

export default function TournamentDetailsScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const [activeTab, setActiveTab] = useState('overview');
  
  // Get the tournament data from route params
  const tournament = route.params?.tournament || {};

  const handleRegister = () => {
    navigation.navigate('Register' as never, { tournament } as never);
  };

  const renderScheduleItem = ({ item }) => (
    <View style={styles.scheduleItem}>
      <View style={styles.scheduleRound}>
        <Text style={styles.scheduleRoundText}>{item.round}</Text>
        <View style={[
          styles.statusBadge, 
          { backgroundColor: item.status === 'upcoming' ? '#E3F2FD' : '#E8F5E9' }
        ]}>
          <Text style={[
            styles.statusText, 
            { color: item.status === 'upcoming' ? '#2196F3' : '#4CAF50' }
          ]}>
            {item.status === 'upcoming' ? 'Upcoming' : 'Completed'}
          </Text>
        </View>
      </View>
      <View style={styles.scheduleDetails}>
        <View style={styles.scheduleInfo}>
          <MaterialIcons name="event" size={16} color="#5C6BC0" />
          <Text style={styles.scheduleInfoText}>{item.date}</Text>
        </View>
        <View style={styles.scheduleInfo}>
          <Ionicons name="time-outline" size={16} color="#FF9800" />
          <Text style={styles.scheduleInfoText}>{item.time}</Text>
        </View>
      </View>
    </View>
  );

  const renderRuleItem = ({ item, index }) => (
    <View style={styles.ruleItem}>
      <Text style={styles.ruleNumber}>{index + 1}</Text>
      <Text style={styles.ruleText}>{item}</Text>
    </View>
  );

  const renderPrizeItem = ({ item, index }) => (
    <View style={styles.prizeItem}>
      {index === 0 && (
        <View style={styles.trophyIconContainer}>
          <MaterialCommunityIcons name="trophy" size={24} color="#FFD700" />
        </View>
      )}
      <View style={styles.prizeContent}>
        <Text style={styles.prizeRank}>{item.rank}</Text>
        <Text style={styles.prizeMoney}>{item.prize}</Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      <View style={styles.header}>
        <Image 
          source={{ uri: tournament.image }} 
          style={styles.headerImage} 
        />
        <LinearGradient
          colors={['rgba(0,0,0,0.7)', 'transparent']}
          style={styles.headerGradient}
        >
          <View style={styles.headerControls}>
            <TouchableOpacity 
              style={styles.backButton}
              onPress={() => navigation.goBack()}
            >
              <Ionicons name="chevron-back" size={24} color="#fff" />
            </TouchableOpacity>
            <View style={styles.headerActions}>
              <TouchableOpacity style={styles.headerAction}>
                <Ionicons name="share-social-outline" size={22} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.headerAction}>
                <Ionicons name="bookmark-outline" size={22} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        </LinearGradient>
      </View>
      
      <View style={styles.tournamentInfo}>
        <View style={styles.gameTagContainer}>
          <Text style={styles.gameTag}>{tournament.game}</Text>
        </View>
        <Text style={styles.tournamentTitle}>{tournament.title}</Text>
        
        <View style={styles.organizerRow}>
          <Text style={styles.byText}>By </Text>
          <Text style={styles.organizerName}>{tournament.organizer}</Text>
          {tournament.verifiedOrganizer && (
            <MaterialIcons name="verified" size={16} color="#4361ee" style={styles.verifiedIcon} />
          )}
        </View>
        
        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <FontAwesome5 name="trophy" size={14} color="#FFD700" />
            <Text style={styles.statText}>Prize: {tournament.prize}</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <MaterialIcons name="people" size={16} color="#FF9800" />
            <Text style={styles.statText}>Slots: {tournament.slots}</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <FontAwesome5 name="gamepad" size={14} color="#9C27B0" />
            <Text style={styles.statText}>Format: {tournament.format}</Text>
          </View>
        </View>
      </View>
      
      <View style={styles.tabButtons}>
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'overview' && styles.activeTabButton]}
          onPress={() => setActiveTab('overview')}
        >
          <Text style={[styles.tabButtonText, activeTab === 'overview' && styles.activeTabText]}>Overview</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'schedule' && styles.activeTabButton]}
          onPress={() => setActiveTab('schedule')}
        >
          <Text style={[styles.tabButtonText, activeTab === 'schedule' && styles.activeTabText]}>Schedule</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'rules' && styles.activeTabButton]}
          onPress={() => setActiveTab('rules')}
        >
          <Text style={[styles.tabButtonText, activeTab === 'rules' && styles.activeTabText]}>Rules</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'prizes' && styles.activeTabButton]}
          onPress={() => setActiveTab('prizes')}
        >
          <Text style={[styles.tabButtonText, activeTab === 'prizes' && styles.activeTabText]}>Prizes</Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView 
        style={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {activeTab === 'overview' && (
          <View style={styles.overviewContent}>
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>About Tournament</Text>
              <Text style={styles.descriptionText}>
                Join the most competitive {tournament.game} tournament of the season! 
                This {tournament.format} tournament brings together top players to compete for glory and prizes.
                The tournament follows a bracket-style elimination format and will be streamed live.
              </Text>
            </View>
            
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>Important Dates</Text>
              <View style={styles.dateItem}>
                <View style={styles.dateIconContainer}>
                  <MaterialIcons name="event-available" size={18} color="#4361ee" />
                </View>
                <View style={styles.dateInfo}>
                  <Text style={styles.dateTitle}>Registration Deadline</Text>
                  <Text style={styles.dateValue}>June 14, 2023 • 11:59 PM</Text>
                </View>
              </View>
              <View style={styles.dateItem}>
                <View style={styles.dateIconContainer}>
                  <MaterialIcons name="event" size={18} color="#4361ee" />
                </View>
                <View style={styles.dateInfo}>
                  <Text style={styles.dateTitle}>Tournament Start</Text>
                  <Text style={styles.dateValue}>June 15, 2023 • 2:00 PM</Text>
                </View>
              </View>
              <View style={styles.dateItem}>
                <View style={styles.dateIconContainer}>
                  <MaterialIcons name="emoji-events" size={18} color="#4361ee" />
                </View>
                <View style={styles.dateInfo}>
                  <Text style={styles.dateTitle}>Finals</Text>
                  <Text style={styles.dateValue}>June 20, 2023 • 7:00 PM</Text>
                </View>
              </View>
            </View>
            
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>Contact Information</Text>
              <TouchableOpacity 
                style={styles.contactItem}
                onPress={() => Linking.openURL('mailto:support@gametourney.com')}
              >
                <Ionicons name="mail-outline" size={18} color="#4361ee" />
                <Text style={styles.contactText}>support@gametourney.com</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.contactItem}
                onPress={() => Linking.openURL('https://discord.gg/gametourney')}
              >
                <FontAwesome5 name="discord" size={18} color="#4361ee" />
                <Text style={styles.contactText}>discord.gg/gametourney</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
        
        {activeTab === 'schedule' && (
          <View style={styles.scheduleContent}>
            <FlatList
              data={SCHEDULE}
              renderItem={renderScheduleItem}
              keyExtractor={item => item.id}
              scrollEnabled={false}
              ItemSeparatorComponent={() => <View style={styles.scheduleSeparator} />}
            />
          </View>
        )}
        
        {activeTab === 'rules' && (
          <View style={styles.rulesContent}>
            <FlatList
              data={RULES}
              renderItem={renderRuleItem}
              keyExtractor={(item, index) => index.toString()}
              scrollEnabled={false}
            />
          </View>
        )}
        
        {activeTab === 'prizes' && (
          <View style={styles.prizesContent}>
            <Text style={styles.prizesTotal}>Total Prize Pool: {tournament.prize}</Text>
            <FlatList
              data={PRIZES}
              renderItem={renderPrizeItem}
              keyExtractor={(item, index) => index.toString()}
              scrollEnabled={false}
              contentContainerStyle={styles.prizesList}
            />
          </View>
        )}
      </ScrollView>
      
      <View style={styles.registerContainer}>
        <View style={styles.entryFeeContainer}>
          <Text style={styles.entryFeeLabel}>Entry Fee</Text>
          <Text style={styles.entryFeeValue}>{tournament.entryFee}</Text>
        </View>
        <TouchableOpacity 
          style={styles.registerButton}
          onPress={handleRegister}
        >
          <Text style={styles.registerButtonText}>Register Now</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f9fc',
  },
  header: {
    height: 200,
    position: 'relative',
  },
  headerImage: {
    width: '100%',
    height: '100%',
  },
  headerGradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 100,
  },
  headerControls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderRadius: 20,
  },
  headerActions: {
    flexDirection: 'row',
  },
  headerAction: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderRadius: 20,
    marginLeft: 8,
  },
  tournamentInfo: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  gameTagContainer: {
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    backgroundColor: '#E3F2FD',
    borderRadius: 12,
    marginBottom: 8,
  },
  gameTag: {
    fontSize: 12,
    fontWeight: '500',
    color: '#2196F3',
  },
  tournamentTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  organizerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  byText: {
    fontSize: 14,
    color: '#888',
  },
  organizerName: {
    fontSize: 14,
    fontWeight: '500',
    color: '#666',
  },
  verifiedIcon: {
    marginLeft: 4,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    fontSize: 13,
    color: '#666',
    marginLeft: 6,
  },
  statDivider: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#ccc',
    marginHorizontal: 8,
  },
  tabButtons: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    paddingTop: 8,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTabButton: {
    borderBottomWidth: 2,
    borderBottomColor: '#4361ee',
  },
  tabButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#888',
  },
  activeTabText: {
    color: '#4361ee',
  },
  content: {
    flex: 1,
    backgroundColor: '#fff',
  },
  overviewContent: {
    padding: 16,
  },
  sectionContainer: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  descriptionText: {
    fontSize: 14,
    lineHeight: 22,
    color: '#666',
  },
  dateItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  dateIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#E8EAF6',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  dateInfo: {
    flex: 1,
  },
  dateTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
    marginBottom: 2,
  },
  dateValue: {
    fontSize: 13,
    color: '#666',
  },
  contactItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  contactText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 10,
  },
  scheduleContent: {
    padding: 16,
  },
  scheduleItem: {
    backgroundColor: '#f9f9f9',
    borderRadius: 12,
    padding: 16,
  },
  scheduleRound: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  scheduleRoundText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '500',
  },
  scheduleDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  scheduleInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  scheduleInfoText: {
    fontSize: 13,
    color: '#666',
    marginLeft: 6,
  },
  scheduleSeparator: {
    height: 12,
  },
  rulesContent: {
    padding: 16,
  },
  ruleItem: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  ruleNumber: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#E3F2FD',
    textAlign: 'center',
    lineHeight: 24,
    fontSize: 12,
    fontWeight: 'bold',
    color: '#2196F3',
    marginRight: 12,
  },
  ruleText: {
    flex: 1,
    fontSize: 14,
    color: '#666',
    lineHeight: 22,
  },
  prizesContent: {
    padding: 16,
  },
  prizesTotal: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
    textAlign: 'center',
  },
  prizesList: {
    backgroundColor: '#f9f9f9',
    borderRadius: 12,
    padding: 16,
  },
  prizeItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  trophyIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FFF8E1',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  prizeContent: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  prizeRank: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  prizeMoney: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  registerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  entryFeeContainer: {
    marginRight: 16,
  },
  entryFeeLabel: {
    fontSize: 12,
    color: '#888',
  },
  entryFeeValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  registerButton: {
    flex: 1,
    backgroundColor: '#4361ee',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  registerButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});