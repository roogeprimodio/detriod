import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  Image, 
  TextInput,
  StatusBar
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const GAMES = [
  {
    id: '1',
    name: 'Call of Duty Mobile',
    image: 'https://api.a0.dev/assets/image?text=Call%20of%20Duty%20Mobile%20Game%20Cover&aspect=16:9&seed=1001',
    players: '10M+',
    tournaments: 37,
  },
  {
    id: '2',
    name: 'PUBG Mobile',
    image: 'https://api.a0.dev/assets/image?text=PUBG%20Mobile%20Game%20Cover&aspect=16:9&seed=1002',
    players: '50M+',
    tournaments: 42,
  },
  {
    id: '3',
    name: 'Fortnite',
    image: 'https://api.a0.dev/assets/image?text=Fortnite%20Game%20Cover&aspect=16:9&seed=1003',
    players: '80M+',
    tournaments: 29,
  },
  {
    id: '4',
    name: 'Free Fire',
    image: 'https://api.a0.dev/assets/image?text=Free%20Fire%20Game%20Cover&aspect=16:9&seed=1004',
    players: '100M+',
    tournaments: 35,
  },
  {
    id: '5',
    name: 'League of Legends: Wild Rift',
    image: 'https://api.a0.dev/assets/image?text=League%20of%20Legends%20Wild%20Rift%20Game%20Cover&aspect=16:9&seed=1005',
    players: '5M+',
    tournaments: 22,
  },
  {
    id: '6',
    name: 'Mobile Legends',
    image: 'https://api.a0.dev/assets/image?text=Mobile%20Legends%20Game%20Cover&aspect=16:9&seed=1006',
    players: '70M+',
    tournaments: 31,
  },
  {
    id: '7',
    name: 'Arena of Valor',
    image: 'https://api.a0.dev/assets/image?text=Arena%20of%20Valor%20Game%20Cover&aspect=16:9&seed=1007',
    players: '8M+',
    tournaments: 18,
  },
  {
    id: '8',
    name: 'Clash Royale',
    image: 'https://api.a0.dev/assets/image?text=Clash%20Royale%20Game%20Cover&aspect=16:9&seed=1008',
    players: '60M+',
    tournaments: 25,
  },
];

const CATEGORIES = [
  'All Games',
  'Battle Royale',
  'MOBA',
  'FPS',
  'Strategy',
  'Racing',
  'Sports'
];

export default function GameSelectionScreen() {
  const navigation = useNavigation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(CATEGORIES[0]);
  
  const filteredGames = GAMES.filter(game => 
    game.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleGamePress = (game) => {
    navigation.navigate('TournamentList' as never, { game } as never);
  };

  const renderGameItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.gameCard}
      onPress={() => handleGamePress(item)}
    >
      <Image source={{ uri: item.image }} style={styles.gameImage} />
      <View style={styles.gameInfo}>
        <View>
          <Text style={styles.gameName}>{item.name}</Text>
          <Text style={styles.gamePlayers}>{item.players} players</Text>
        </View>
        <View style={styles.tournamentBadge}>
          <Text style={styles.tournamentCount}>{item.tournaments}</Text>
          <Text style={styles.tournamentLabel}>Tournaments</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderCategoryItem = ({ item }) => (
    <TouchableOpacity
      style={[
        styles.categoryButton,
        selectedCategory === item && styles.activeCategoryButton
      ]}
      onPress={() => setSelectedCategory(item)}
    >
      <Text 
        style={[
          styles.categoryText,
          selectedCategory === item && styles.activeCategoryText
        ]}
      >
        {item}
      </Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="chevron-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Games</Text>
        <TouchableOpacity style={styles.searchButton}>
          <Ionicons name="notifications-outline" size={24} color="#333" />
        </TouchableOpacity>
      </View>
      
      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#888" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search games..."
          placeholderTextColor="#888"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        {searchQuery.length > 0 && (
          <TouchableOpacity 
            style={styles.clearButton}
            onPress={() => setSearchQuery('')}
          >
            <Ionicons name="close-circle" size={18} color="#888" />
          </TouchableOpacity>
        )}
      </View>
      
      <View style={styles.categoriesList}>
        <FlatList
          data={CATEGORIES}
          renderItem={renderCategoryItem}
          keyExtractor={(item) => item}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesContainer}
        />
      </View>
      
      <View style={styles.gamesContainer}>
        <FlatList
          data={filteredGames}
          renderItem={renderGameItem}
          keyExtractor={item => item.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.gamesList}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f9fc',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  searchButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    marginHorizontal: 16,
    marginTop: 16,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#eee',
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    height: 40,
    fontSize: 16,
    color: '#333',
  },
  clearButton: {
    padding: 4,
  },
  categoriesList: {
    marginTop: 16,
  },
  categoriesContainer: {
    paddingHorizontal: 12,
  },
  categoryButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#eee',
    marginHorizontal: 4,
  },
  activeCategoryButton: {
    backgroundColor: '#4361ee',
  },
  categoryText: {
    color: '#666',
    fontWeight: '500',
  },
  activeCategoryText: {
    color: '#fff',
  },
  gamesContainer: {
    flex: 1,
    marginTop: 16,
  },
  gamesList: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  gameCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 3,
  },
  gameImage: {
    width: '100%',
    height: 120,
  },
  gameInfo: {
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  gameName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  gamePlayers: {
    fontSize: 12,
    color: '#888',
  },
  tournamentBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: '#e6effd',
    alignItems: 'center',
  },
  tournamentCount: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4361ee',
  },
  tournamentLabel: {
    fontSize: 10,
    color: '#4361ee',
  },
});