import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons, FontAwesome5, Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';

const TOURNAMENTS = [
  {
    id: '1',
    title: 'Pro League Season 5',
    game: 'Call of Duty Mobile',
    prize: '$5,000',
    image: 'https://api.a0.dev/assets/image?text=Call%20of%20Duty%20Tournament%20Poster&aspect=16:9&seed=123',
    date: 'Jun 15-20',
    slots: '32/64',
  },
  {
    id: '2',
    title: 'Ultimate Showdown',
    game: 'PUBG Mobile',
    prize: '$3,500',
    image: 'https://api.a0.dev/assets/image?text=PUBG%20Mobile%20Tournament%20Banner&aspect=16:9&seed=456',
    date: 'Jun 22-25',
    slots: '45/100',
  },
  {
    id: '3',
    title: 'Mythic Cup',
    game: 'Fortnite',
    prize: '$7,000',
    image: 'https://api.a0.dev/assets/image?text=Fortnite%20Tournament%20Competition&aspect=16:9&seed=789',
    date: 'Jul 1-10',
    slots: '120/200',
  },
];

const LIVE_MATCHES = [
  {
    id: '1',
    team1: 'Voltage Esports',
    team2: 'Phoenix Gaming',
    game: 'Call of Duty Mobile',
    time: 'LIVE',
    viewers: '15.4K',
  },
  {
    id: '2',
    team1: 'Dragon Squad',
    team2: 'Alpha Wolves',
    game: 'PUBG Mobile',
    time: 'In 2 hrs',
    viewers: '8.2K',
  },
];

const REGISTERED_MATCHES = [
  {
    id: '1',
    title: 'Pro League Qualifier',
    game: 'Call of Duty Mobile',
    time: 'Today, 5:00 PM',
    status: 'Upcoming',
  },
  {
    id: '2',
    title: 'Weekly Scrim',
    game: 'PUBG Mobile',
    time: 'Tomorrow, 8:00 PM',
    status: 'Registered',
  },
];

export default function HomeScreen() {
  const navigation = useNavigation();

  const navigateToScreen = (screen: string, params = {}) => {
    navigation.navigate(screen as never, params as never);
  };

  const renderTournamentItem = ({ item }: { item: typeof TOURNAMENTS[0] }) => (
    <TouchableOpacity 
      style={styles.tournamentCard}
      onPress={() => navigateToScreen('TournamentList')}
    >
      <Image source={{ uri: item.image }} style={styles.tournamentImage} />
      <View style={styles.tournamentOverlay}>
        <Text style={styles.tournamentGame}>{item.game}</Text>
        <Text style={styles.tournamentTitle}>{item.title}</Text>
        <View style={styles.tournamentInfoRow}>
          <Text style={styles.tournamentPrize}>💰 {item.prize}</Text>
          <Text style={styles.tournamentDate}>📅 {item.date}</Text>
          <Text style={styles.tournamentSlots}>👥 {item.slots}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderLiveMatch = ({ item }: { item: typeof LIVE_MATCHES[0] }) => (
    <TouchableOpacity 
      style={styles.liveMatchCard}
      onPress={() => navigateToScreen('MatchDetails', { match: item })}
    >
      <LinearGradient
        colors={['#1e3c72', '#2a5298']}
        style={styles.liveMatchGradient}
      >
        <View style={styles.liveMatchTeams}>
          <Text style={styles.liveMatchTeam}>{item.team1}</Text>
          <Text style={styles.liveMatchVs}>VS</Text>
          <Text style={styles.liveMatchTeam}>{item.team2}</Text>
        </View>
        <Text style={styles.liveMatchGame}>{item.game}</Text>
        <View style={styles.liveStatusContainer}>
          {item.time === 'LIVE' ? (
            <>
              <View style={styles.liveDot} />
              <Text style={styles.liveText}>{item.time}</Text>
            </>
          ) : (
            <Text style={styles.upcomingText}>{item.time}</Text>
          )}
          <Text style={styles.viewers}><Ionicons name="eye" size={14} /> {item.viewers}</Text>
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );

  const renderRegisteredMatch = ({ item }: { item: typeof REGISTERED_MATCHES[0] }) => (
    <TouchableOpacity 
      style={styles.registeredMatchCard}
      onPress={() => navigateToScreen('MatchDetails', { match: item })}
    >
      <View style={styles.registeredMatchContent}>
        <View>
          <Text style={styles.registeredMatchTitle}>{item.title}</Text>
          <Text style={styles.registeredMatchGame}>{item.game}</Text>
          <Text style={styles.registeredMatchTime}>{item.time}</Text>
        </View>
        <View style={[
          styles.statusBadge, 
          item.status === 'Upcoming' ? styles.upcomingBadge : styles.registeredBadge
        ]}>
          <Text style={styles.statusText}>{item.status}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Hello, Player</Text>
            <Text style={styles.subtitle}>Ready for your matches today?</Text>
          </View>
          <TouchableOpacity onPress={() => navigateToScreen('Profile')}>
            <View style={styles.profilePic}>
              <Text style={styles.profileInitial}>P</Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.quickActions}>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => navigateToScreen('GameSelection')}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#FF6B6B' }]}>
              <FontAwesome5 name="gamepad" size={20} color="#fff" />
            </View>
            <Text style={styles.actionText}>Games</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => navigateToScreen('RegisteredMatches')}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#4ECDC4' }]}>
              <MaterialIcons name="sports-esports" size={22} color="#fff" />
            </View>
            <Text style={styles.actionText}>Matches</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => navigateToScreen('Teams')}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#FFD166' }]}>
              <FontAwesome5 name="users" size={18} color="#fff" />
            </View>
            <Text style={styles.actionText}>Teams</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => navigateToScreen('Wallet')}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#6A0572' }]}>
              <FontAwesome5 name="wallet" size={18} color="#fff" />
            </View>
            <Text style={styles.actionText}>Wallet</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Upcoming Tournaments</Text>
            <TouchableOpacity onPress={() => navigateToScreen('TournamentList')}>
              <Text style={styles.seeAll}>See All</Text>
            </TouchableOpacity>
          </View>
          <FlatList
            data={TOURNAMENTS}
            renderItem={renderTournamentItem}
            keyExtractor={item => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.tournamentList}
          />
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Live Matches</Text>
            <TouchableOpacity>
              <Text style={styles.seeAll}>See All</Text>
            </TouchableOpacity>
          </View>
          <FlatList
            data={LIVE_MATCHES}
            renderItem={renderLiveMatch}
            keyExtractor={item => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.liveMatchesList}
          />
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Your Registered Matches</Text>
            <TouchableOpacity onPress={() => navigateToScreen('RegisteredMatches')}>
              <Text style={styles.seeAll}>See All</Text>
            </TouchableOpacity>
          </View>
          <FlatList
            data={REGISTERED_MATCHES}
            renderItem={renderRegisteredMatch}
            keyExtractor={item => item.id}
            scrollEnabled={false}
            contentContainerStyle={styles.registeredMatchesList}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f9fc',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  greeting: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1a1a2e',
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  profilePic: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#4361ee',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInitial: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginVertical: 16,
  },
  actionButton: {
    alignItems: 'center',
  },
  actionIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  actionText: {
    fontSize: 12,
    color: '#333',
  },
  section: {
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1a1a2e',
  },
  seeAll: {
    fontSize: 14,
    color: '#4361ee',
  },
  tournamentList: {
    paddingHorizontal: 12,
  },
  tournamentCard: {
    width: 270,
    height: 150,
    marginHorizontal: 4,
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  tournamentImage: {
    width: '100%',
    height: '100%',
  },
  tournamentOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.6)',
    padding: 10,
  },
  tournamentGame: {
    color: '#fff',
    fontSize: 12,
    opacity: 0.8,
  },
  tournamentTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  tournamentInfoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  tournamentPrize: {
    color: '#fff',
    fontSize: 12,
  },
  tournamentDate: {
    color: '#fff',
    fontSize: 12,
  },
  tournamentSlots: {
    color: '#fff',
    fontSize: 12,
  },
  liveMatchesList: {
    paddingHorizontal: 12,
  },
  liveMatchCard: {
    width: 200,
    height: 120,
    marginHorizontal: 4,
    borderRadius: 12,
    overflow: 'hidden',
  },
  liveMatchGradient: {
    width: '100%',
    height: '100%',
    padding: 12,
    justifyContent: 'space-between',
  },
  liveMatchTeams: {
    alignItems: 'center',
  },
  liveMatchTeam: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  liveMatchVs: {
    color: '#fff',
    fontSize: 12,
    marginVertical: 4,
    opacity: 0.8,
  },
  liveMatchGame: {
    color: '#fff',
    fontSize: 12,
    opacity: 0.9,
    textAlign: 'center',
    marginTop: 4,
  },
  liveStatusContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 4,
  },
  liveDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#ff4757',
    marginRight: 5,
  },
  liveText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  upcomingText: {
    color: '#fff',
    fontSize: 12,
  },
  viewers: {
    color: '#fff',
    fontSize: 12,
  },
  registeredMatchesList: {
    paddingHorizontal: 16,
  },
  registeredMatchCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 1.41,
    elevation: 2,
  },
  registeredMatchContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  registeredMatchTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  registeredMatchGame: {
    fontSize: 13,
    color: '#666',
    marginTop: 4,
  },
  registeredMatchTime: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  upcomingBadge: {
    backgroundColor: '#FFECB3',
  },
  registeredBadge: {
    backgroundColor: '#C8E6C9',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
});